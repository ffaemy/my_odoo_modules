/** @odoo-module **/

import { Component, useState, onWillUnmount, onMounted } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

export class TaskNotificationWidget extends Component {
    setup() {
        this.state = useState({
            tasks: [],
            dropdownOpen: false,
        });
        this.rpc = useService("rpc");
        this.actionService = useService("action");

        this.loadTasks = this.loadTasks.bind(this);
        this.toggleDropdown = this.toggleDropdown.bind(this);
        this.openTask = this.openTask.bind(this);

        onMounted(() => {
            this.loadTasks();
            this.interval = setInterval(this.loadTasks, 5000);
        });

        onWillUnmount(() => {
            clearInterval(this.interval);
        });
    }

    async loadTasks() {
        try {
            const tasks = await this.rpc("/task_notification/tasks", {});
            console.log("Tasks loaded:", tasks);
            this.state.tasks = tasks || [];
        } catch (e) {
            console.error("❌ Failed to fetch tasks:", e);
            this.state.tasks = [];
        }
    }

    toggleDropdown() {
        console.log("Toggling dropdown, current state:", this.state.dropdownOpen);
        this.state.dropdownOpen = !this.state.dropdownOpen;
    }

    openTask(taskId) {
        console.log("Opening task with ID:", taskId);
        if (!taskId) return;
        this.actionService.doAction({
            type: "ir.actions.act_window",
            res_model: "project.task",
            res_id: taskId,
            views: [[false, "form"]],
            target: "current",
        });
    }
}

TaskNotificationWidget.template = "owl_notification_widget.TaskNotificationWidget";

registry.category("systray").add("task_notification_widget", {
    Component: TaskNotificationWidget,
    sequence: 100,
});