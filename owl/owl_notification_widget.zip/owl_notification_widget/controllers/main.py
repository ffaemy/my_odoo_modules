from odoo import http
from odoo.http import request

class TaskNotificationController(http.Controller):

    @http.route('/task_notification/tasks', type='json', auth='user')
    def get_tasks(self):
        tasks = request.env['project.task'].sudo().search([
            ('state', '=', '01_in_progress')
        ])
        return tasks.read(['id', 'name', 'state'])
